package classTestTwo;

import static org.junit.Assert.*;

import org.junit.Test;

public class testingClassScan {

	@Test
	public void testSmartScan() {
		SmartScanner s = new SmartScanner("1,abc,2,def");
		s.smartScan();
	}

	@Test
	public void testSmartScan2() {
		SmartScanner s = new SmartScanner("1,abc,2,def,notANumber,text");
		s.smartScan();
	}

}
