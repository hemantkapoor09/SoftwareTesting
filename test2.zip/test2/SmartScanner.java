package classTestTwo;

import java.util.Scanner;

public class SmartScanner {
	Scanner sc = new Scanner(System.in);
	String inp ="";
	String[] parts ={};
	int flag=0;
	public SmartScanner(String inp){
		this.inp=inp;
	}
	public void input(){
		System.out.println("Enter the string in <Int,String> Format");
		inp=sc.nextLine();	
	}
	public String testInp(){
		
		return this.inp;
		
	}
	
		
	public void smartScan(){
		String value="def";
		String key="def";
		
		
		parts = inp.split(",");
		
		for(int i=0;i<parts.length;i++){
			String temp= parts[i];
			
			if(isNumber(temp)){
				key=parts[i];
				System.out.println(key);
			}
			else{
				parts[i]="def";
			}
			i+=1;
			value=parts[i];
			System.out.println(value);
		}
		
		for(int i=0;i<parts.length;i++){
				if(parts[i]=="def"){
					flag=1;
				}
				
			}
			if(flag==1){
				System.out.println("Exception Found You are not satisfying precondition");
			}
	}

	
		

	public boolean isNumber(String s) 
	{ 
		for (int i = 0; i < s.length(); i++) 
		if (Character.isDigit(s.charAt(i)) 
			== false) 
			return false; 

		return true; 
	} 
}
