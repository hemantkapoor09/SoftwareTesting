package test;

public class MyClass {
	public String username;
	public String password;

	
	
	public MyClass(String username, String password) {
		this.username = username;
		this.password = password;
	}
	

	public boolean empt(){
		boolean emptyFlag = false;
		
		if(this.username.isEmpty()){
			emptyFlag = true;
		}
		else if(this.password.isEmpty()){
			emptyFlag = true;
		}
		
		return emptyFlag;	
	}
	
	// Username contains capital letters
	public boolean cap(){
		boolean captialFlag = false;
		String str = this.username;
		for(int i=str.length()-1; i>=0; i--) {
	        if(Character.isUpperCase(str.charAt(i))) {
	           captialFlag = true;
	        }
	    }		
	
		return captialFlag;
	}
//	Password contains any of these characters: �!#$%�
	public boolean containsSpec(){
		boolean containsSpecialCahr = false;
		
		if(
				this.password.contains("!") ||
				this.password.contains("#") ||
				this.password.contains("$") ||
				this.password.contains("%") ){
			
			containsSpecialCahr = true;
		}
		
		return containsSpecialCahr;
	}
	
//	Password length is less than 8 characters and bigger than 12 characters
	public boolean lenthOfPass(){
		boolean lenthOfPassword = true;
		if(this.password.length()<8 || this.password.length()>12){
			lenthOfPassword=false;
		}
		return lenthOfPassword;
	}
	}