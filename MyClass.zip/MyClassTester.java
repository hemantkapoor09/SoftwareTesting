package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyClassTester {

	//assertEquals("message", expectedValue, value)	
	public boolean logIn(String username, String password){
		
		System.out.println("Was Testing User For Login with Credentials \n Username = "+username+" Password = "+password);
		
		return true;
	}
	
	@Test
	public void test1() {
		MyClass mc1 = new MyClass("TestUser","abc12345!");
	
		assertEquals("Null Credentials Exception", false, mc1.empt());
		assertEquals("capital letters in username",true,mc1.cap());
		assertEquals("must include any of these !#$% in password",true,mc1.containsSpec());
		assertEquals("must be in between lenth of 8-12 ",true,mc1.lenthOfPass());
		logIn("TestUser","abc123!");
		
		
	}
	
	@Test
	public void test2() {
		MyClass mc1 = new MyClass("","");
	
		assertEquals("Null Credentials Exception in Test1", true, mc1.empt());
		assertEquals("capital letters in username of Test1",false,mc1.cap());
		assertEquals("Test1 must include any of these !#$% in password",false,mc1.containsSpec());
		assertEquals("Test1 must be in between lenth of 8-12 ",false,mc1.lenthOfPass());
		logIn("","");
	}
	

	@Test
	public void test3() {
		MyClass mc1 = new MyClass("abc","123");
	
		assertEquals("Null Credentials Exception in Test1", false, mc1.empt());
		assertEquals("capital letters in username of Test1",false,mc1.cap());
		assertEquals("Test1 must include any of these !#$% in password",false,mc1.containsSpec());
		assertEquals("Test1 must be in between lenth of 8-12 ",false,mc1.lenthOfPass());
		logIn("abc","123");
	}
		
}
