package credit_rewards_card;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestingCards {

	@Test
	public void test1(){
		CreditRewardsCard cr = new CreditRewardsCard("Test","ing","123456cc","654321rw",0,0);
		cr.pay(45);
			cr.pay(20);
		
		cr.payBill(40);
		
		cr.getStatus();
		
		assertEquals(25,25,cr.getBalance());
	}
	
	@Test
	public void test2(){
		CreditRewardsCard cr = new CreditRewardsCard("Abc","def","999999cc","8888888rw",0,0);
		cr.pay(1045);
		
		cr.payBill(45);
			cr.payBill(500);
		
		cr.getStatus();
		
		assertEquals(500,500,cr.getBalance());
	}
}
