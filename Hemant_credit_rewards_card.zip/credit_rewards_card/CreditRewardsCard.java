package credit_rewards_card;

public class CreditRewardsCard {
	private String fname;
	private String lname;
	private String ccardNumber;
	private String rewardcardNumber;
	private float balance;
	private float points;

	public CreditRewardsCard(String fname,String lname, String ccardNumber, String rewardcardNumber, float balance, float points) {
		this.fname = fname;
		this.lname = lname;
		this.ccardNumber = ccardNumber;
		this.rewardcardNumber = rewardcardNumber;
		this.balance = balance;
		this.points = points;
	}

	public float pay(float amt){
		this.balance+= amt;
		this.points += amt;
		return this.balance;	
	}
	
	public float payBill(float amt){
		this.balance -= amt;
		return this.balance;	
	}
	
	public void getStatus(){
		System.out.println("<> For User [ "+this.fname+"-"+this.lname+" ] \nBalance On \n \t >Credit Card = "+this.balance+"\n \t >Reward-Points = "+this.points);		
	}
	
	public float getBalance(){
		System.out.println("Balance on credit card = "+this.balance+"\n\n");
		return this.balance;
		
	}
	
}
