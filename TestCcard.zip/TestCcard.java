import static org.junit.Assert.*;


import org.junit.Test;

public class TestCcard {

	@Test
	public void testCc1() {
		Ccard cc1=new Ccard("xyz","abc","12345678",0);
		cc1.exepCcInst();
		cc1.tokenizerMethod();
	}

	@Test
	public void testCc2() {
		Ccard cc2=new Ccard("Don","Bosko","925252522",0);
		cc2.exepCcInst();
		cc2.tokenizerMethod();
	}
	
	@Test
	public void testCc3() {
		Ccard cc3=new Ccard("Ranldo","Singh","624792282",0);
		cc3.exepCcInst();
		cc3.tokenizerMethod();
	}
	

}
