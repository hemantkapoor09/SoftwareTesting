import java.util.StringTokenizer;

public class Ccard {
	private String fname;
	private String lname;
	private String ccardNumber;
	private float balance;
	public static int counter=0;
	 
	public Ccard(String fname,String lname, String ccardNumber,float balance) {
	
		this.fname = fname;
		this.lname = lname;
		this.ccardNumber = ccardNumber;
		this.balance = balance;
		counter++;
	}
	 
	public void exepCcInst()
	{
		if(counter > 1){
			System.out.println("\t !! Credit Card Can not be created[credit card instantiated ONLY once] !!");
			System.exit(0);
		}
		
	}	
	
	public void tokenizerMethod(){
		String inp =" First_Name=="+fname+" Last_Name=="+lname+" Credit_Card_Number=="+ccardNumber+" Balance=="+balance+" ";
		StringTokenizer st = new StringTokenizer(inp," ");
		
		int count = st.countTokens();
		System.out.println("Number of tokens:"+count);
		
		// Counting the tokens 
        System.out.println("The number of Tokens are: "+ st.countTokens()); 
  
        // Checking for any tokens 
        System.out.println(st.hasMoreTokens()); 
  
        // Checking and displaying the Tokens 
        while (st.hasMoreTokens()) { 
            System.out.println("The Next token: "+ st.nextToken()); 
        } 
		
	}
	
//	public static boolean getNumOfInstances() {
//		boolean flag=true;
//		if(counter > 1)
//		{
//			flag=false;
//		}
//			return flag;
//		
//    }

}
